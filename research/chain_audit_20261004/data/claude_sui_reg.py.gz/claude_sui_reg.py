import json,math,bisect,datetime as dt,statistics as st
r=json.load(open('rows.json')); kl=json.load(open('kl.json'))
def Gsym(s,t0,t1):
    v=[k for k in kl[s] if t0<=k[0]<=t1]; return sum(math.log(v[i+1][1]/v[i][1])**2 for i in range(len(v)-1))/8/((t1-t0)/86400e3)
now=dt.datetime(2026,10,4,18).timestamp()*1000
for d in (7,30,89):
    print(f"G {d}d: SOL {Gsym('SOLUSDT',now-d*864e5,now):.2e}  SUI {Gsym('SUIUSDT',now-d*864e5,now):.2e}  BTC {Gsym('BTCUSDT',now-d*864e5,now):.2e}")
# SOL daily G terciles cutoffs for reference; SUI terciles by pool's own G
print()
print(f"{'pool':26s} {'7d F/L':>7s} {'calm':>6s} {'mid':>6s} {'hot':>6s} | {'calm+R':>6s} {'hot+R':>6s} | G cutoffs")
for n,v in r.items():
    o=[x for x in v['out'] if x['G']]
    if not o: continue
    o7=o[-7:]; f7=st.mean(x['Y'] for x in o7)/st.mean(x['G'] for x in o7)
    s=sorted(o,key=lambda x:x['G']); k=len(s)//3
    parts=[s[:k],s[k:2*k],s[2*k:]]
    fl=[st.mean(x['Y'] for x in p)/st.mean(x['G'] for x in p) for p in parts]
    flr=[st.mean(x['Y']+x['R'] for x in p)/st.mean(x['G'] for x in p) for p in parts]
    print(f"{n:26s} {f7:7.2f} {fl[0]:6.2f} {fl[1]:6.2f} {fl[2]:6.2f} | {flr[0]:6.2f} {flr[2]:6.2f} | {s[k]['G']:.1e} {s[2*k]['G']:.1e}")
