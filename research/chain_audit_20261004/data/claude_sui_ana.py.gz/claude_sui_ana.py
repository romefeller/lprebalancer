import json,re,math,bisect,datetime as dt,statistics as st
snap=json.load(open('snap.json')); meta=json.load(open('meta.json')); kl=json.load(open('kl.json'))
Q=2**64; M128=2**128
def norm_t(t): return t if t.startswith('0x') else '0x'+t
dec={k:v['decimals'] for k,v in meta.items()}; sym={k:v['symbol'] for k,v in meta.items()}
# price series $ per token from binance closes
ser={s:([k[0] for k in v],[k[1] for k in v]) for s,v in kl.items()}
def px(s,tms):
    ts,cl=ser[s]; i=min(max(bisect.bisect_left(ts,tms),0),len(ts)-1); return cl[i]
def usd(symb,tms):
    return {'USDC':lambda:1.0,'SUI':lambda:px('SUIUSDT',tms),'CETUS':lambda:px('CETUSUSDT',tms),'DEEP':lambda:px('DEEPUSDT',tms),
            'WAL':lambda:px('WALUSDT',tms),'HAEDAL':lambda:px('HAEDALUSDT',tms),'xBTC':lambda:px('BTCUSDT',tms),'LBTC':lambda:px('BTCUSDT',tms),
            'ETH':lambda:px('ETHUSDT',tms),'stSUI':lambda:1.039*px('SUIUSDT',tms),'haSUI':lambda:1.082*px('SUIUSDT',tms),
            'xSUI':lambda:1.007*px('SUIUSDT',tms),'BLUE':lambda:0.0102}.get(symb,lambda:0.0)()
def G(base,quote,t0,t1):
    # sum r^2/8 of 5-min log returns of base/quote between t0,t1 (ms) ; quote USDC => base only
    bs={'xBTC':'BTCUSDT','LBTC':'BTCUSDT','stSUI':'SUIUSDT','haSUI':None}.get(base,base+'USDT')
    qs=None if quote=='USDC' else ({'SUI':'SUIUSDT'}[quote])
    if bs is None: return None
    ts,cb=ser[bs]; i0=bisect.bisect_left(ts,t0); i1=bisect.bisect_left(ts,t1)
    if qs:
        tq,cq=ser[qs]; dq=dict(zip(tq,cq)); c=[cb[i]/dq[ts[i]] for i in range(i0,min(i1+1,len(ts))) if ts[i] in dq]
    else: c=cb[i0:i1+1]
    return sum(math.log(c[i+1]/c[i])**2 for i in range(len(c)-1))/8
by={}
for x in snap:
    if 'err' in x: continue
    by.setdefault(x['name'],[]).append(x)
rows={}
for name,L in by.items():
    L.sort(key=lambda x:x['cp'])
    m=re.search(r'Pool<(.+),\s*(.+)>$',L[0]['type']); A,B=m.group(1),m.group(2)
    sa,sb=sym[A],sym[B]
    base,quote=(sa,sb) if sb in('USDC','SUI') and sa not in('USDC',) else (sb,sa)
    if sa=='USDC' and sb=='SUI': base,quote='SUI','USDC'
    out=[]
    for a,b in zip(L,L[1:]):
        t0=dt.datetime.fromisoformat(a['ts'].replace('Z','+00:00')).timestamp()*1000
        t1=dt.datetime.fromisoformat(b['ts'].replace('Z','+00:00')).timestamp()*1000
        days=(t1-t0)/86400e3
        p0=(a['sp']/Q)**2; p1=(b['sp']/Q)**2; p=math.sqrt(p0*p1); sq=math.sqrt(p)
        fA=((b['fa']-a['fa'])%M128)/Q; fB=((b['fb']-a['fb'])%M128)/Q
        Y=(fA*p+fB)/(2*sq)/days
        # $ per raw B
        uB=usd(sb,t1)/10**dec[B]
        R=0.0
        ra=dict(a['rw'])
        for c,g in b['rw']:
            if c in ra:
                dg=((int(g)-int(ra[c]))%M128)/Q
                if dg>1e30: continue
                ct=norm_t(c); R+=dg*usd(sym.get(ct,'?'),t1)/10**dec.get(ct,9)/uB
        R=R/(2*sq)/days
        g=G(base,quote,t0,t1)
        out.append(dict(t=b['ts'][:10],Y=Y,R=R,G=(g/days if g is not None else None),L=b['L'],tvlfr=2*b['L']*math.sqrt((b['sp']/Q)**2)*uB,p=p1*10**dec[A]/10**dec[B]))
    rows[name]=dict(base=base,quote=quote,fee=L[-1]['fee_rate']/1e4,pfs=L[-1]['pfs'],out=out)
json.dump(rows,open('rows.json','w'))
# SOL G same windows
def solG(n):
    o=rows['cetus_USDC_SUI_5bp']['out'][-n:]
    return None
def summ(out,n):
    o=out[-n:]
    Y=st.mean(r['Y'] for r in o); R=st.mean(r['R'] for r in o)
    Gs=[r['G'] for r in o if r['G'] is not None]; Gm=st.mean(Gs) if Gs else float('nan')
    return Y,R,Gm
print(f"{'pool':26s} fee%  {'Y30·201.5':>9s} {'R30·201.5':>9s} {'F/L30':>6s} {'F+R/L30':>7s} | {'Y89·201.5':>9s} {'F/L89':>6s} {'(F+R)/L89':>8s}  FRval$M")
for n,r in sorted(rows.items(),key=lambda kv:-summ(kv[1]['out'],30)[0]):
    Y,R,Gm=summ(r['out'],30); Y9,R9,G9=summ(r['out'],89)
    print(f"{n:26s} {r['fee']:.3f} {Y*201.5*100:8.2f}% {R*201.5*100:8.2f}% {Y/Gm:6.2f} {(Y+R)/Gm:7.2f} | {Y9*201.5*100:8.2f}% {Y9/G9:6.2f} {(Y9+R9)/G9:8.2f}  {r['out'][-1]['tvlfr']/1e6:7.2f}")
