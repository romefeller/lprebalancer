import sys, types, json, numpy as np
sys.modules['engine']=types.ModuleType('engine')
import calm_copy as calm
K=json.load(open('eth5m.json'))
ts=np.array([k[0]/1000 for k in K]); c=np.array([k[1] for k in K]); h=np.array([k[2] for k in K]); l=np.array([k[3] for k in K])
# hourly regime at each hour boundary, trailing 10 days
H=[]
start=ts[0]+10*86400
idx=np.searchsorted(ts, np.arange(start, ts[-1], 3600))
for i in idx:
    j0=max(0,i-2880)
    bars=(ts[j0:i],c[j0:i],h[j0:i],l[j0:i],c[j0:i],np.zeros(i-j0))
    v=calm.regime_view(bars,c[i-1],c[i-1]*0.99,c[i-1]*1.01)
    H.append([float(ts[i]), v['mode'], v['choice_pct']])
json.dump(H,open('regime_h.json','w'))
import collections; print(collections.Counter(x[1] for x in H), len(H))
