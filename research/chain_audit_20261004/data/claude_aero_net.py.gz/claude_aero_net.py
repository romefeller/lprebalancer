import json,numpy as np
rows=json.load(open('rows.json'))
K=json.load(open('../panoptic/eth5m.json')); kt=np.array([k[0]/1000 for k in K]); c=np.array([k[1] for k in K]); h=np.array([k[2] for k in K]); l=np.array([k[3] for k in K])
def exits(t0,t1,k):
    a=np.searchsorted(kt,t0); b=np.searchsorted(kt,t1); n=0; ctr=c[a]
    for i in range(a+1,b):
        if h[i]>ctr*(1+k) or l[i]<ctr*(1-k): n+=1; ctr=c[i]
    return n/((t1-t0)/86400)
lev=lambda k:1/(1-(1+k)**-0.5)
ETH=2705; GW=0.008e-9
GAS_STAKED=(325+198+180+416+462+92+150+46)*1e3   # withdraw(+claim), decrease/collect/burn, swap, mint, deposit, 2 approvals, AERO sale, AERO approve
GAS_UNST=(198+180+416+92)*1e3
SWAP_FEE=0.0005; AERO_SALE=0.0005  # Slipstream AERO/USDC ts100 fee 0.05%; v2 vAMM is 0.30%+ (0.33% measured quote)
rs=rows['v3']; t=np.array([r[0] for r in rs]); RY=np.array([r[1] for r in rs]); FY=np.array([r[2] for r in rs]); LS=np.array([r[3] for r in rs])
T0,T1=t[0],t[-1]; mid=(T0+T1)/2
W={'all165':(T0,T1),'1st half':(T0,mid),'2nd half':(mid,T1),'last90':(T1-90*86400,T1),'last30':(T1-30*86400,T1)}
print('gas $ per staked re-centre %.3f, unstaked re-centre %.3f'%(GAS_STAKED*GW*ETH,GAS_UNST*GW*ETH))
for wn,(a,b) in W.items():
    m=(t>=a)&(t<b); d=m.sum()/24
    rew=RY[m].sum()/d; fee=FY[m].sum()/d; los=LS[m].sum()/d
    print(f'\n[{wn}] rew {rew*1e4:.3f}bp/d FR, unstaked fee {fee*1e4:.3f}, loss {los*1e4:.3f}')
    for C in [230,2000]:
        line=f'  ${C}:'
        best=None
        for k in [0.01,0.02,0.03,0.05]:
            L_=lev(k); ex=exits(a,b,k)
            g=C*L_*rew; lo=C*L_*los
            cost=ex*(GAS_STAKED*GW*ETH + C/2*SWAP_FEE) + g*AERO_SALE
            nr=g-lo-cost; nc=g-0.77*lo-cost
            gu=C*L_*fee; cu=ex*(GAS_UNST*GW*ETH + C/2*SWAP_FEE)
            ur=gu-lo-cu; uc=gu-0.77*lo-cu
            line+=f' | ±{k*100:.0f}% ex{ex:.1f} STK gross {g:.2f} net raw {nr:+.2f} corr {nc:+.2f}; UNST gross {gu:.2f} net raw {ur:+.2f} corr {uc:+.2f}'
        print(line)
