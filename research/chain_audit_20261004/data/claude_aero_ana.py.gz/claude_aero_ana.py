import json, numpy as np, math, collections, time
PAN='../panoptic/'
R=[json.loads(l) for l in open('samples.jsonl')]; R.sort(key=lambda r:r['t'])
K=json.load(open(PAN+'eth5m.json')); kts=np.array([k[0]/1000 for k in K]); kc=np.array([k[1] for k in K])
H=json.load(open(PAN+'regime_h.json')); hts=np.array([x[0] for x in H]); hm=[x[1] for x in H]
Q=2**128
def view_rg(p,t):
    sq,tick,liq,stk,rr,res,rg,lu,fg0,fg1=p
    if stk>0 and res>0 and t>lu:
        rg+=min(rr*(t-lu),res)*Q//stk
    return rg
rows=collections.defaultdict(list)
for i in range(len(R)-1):
    a,b=R[i],R[i+1]; t=b['t']
    j0=np.searchsorted(kts,a['t']); j1=np.searchsorted(kts,b['t'])
    if j1-j0<6: continue
    c=kc[max(j0-1,0):j1]; g=float(np.sum(np.diff(np.log(c))**2))/8
    jh=np.searchsorted(hts,a['t'],side='right')-1
    reg=hm[jh] if jh>=0 else None
    aero=b['aero']
    for n in ['v3','i100']:
        pa,pb=a[n],b[n]
        if not pa or not pb or pa[2]==0: continue
        sqrtp=pb[0]/2**96; eth=sqrtp**2*1e12; fr=2*sqrtp*1e-6
        drg=(view_rg(pb,b['t'])-view_rg(pa,a['t']))%(1<<256)
        ry=drg/Q/1e18*aero/fr
        d0=(pb[8]-pa[8])%(1<<256); d1=(pb[9]-pa[9])%(1<<256)
        fy=(d0/Q*1e-18*eth+d1/Q*1e-6)/fr
        rows[n].append((a['t'],ry,fy,g,reg,aero,eth,pb[3]/pb[2] if pb[2] else 0, pb[4]*86400/1e18))
json.dump(rows,open('rows.json','w'))
lev=lambda k:1/(1-k**-0.5)
for n,rs in rows.items():
    A=np.array([(r[0],r[1],r[2],r[3]) for r in rs])
    t=A[:,0]; days=(t[-1]-t[0])/86400
    print(f'\n== {n}  {time.strftime("%Y-%m-%d",time.gmtime(t[0]))} -> {time.strftime("%Y-%m-%d",time.gmtime(t[-1]))}  {days:.0f} d  hours {len(rs)}')
    # outlier check
    print(' max hourly reward yield',A[:,1].max(),'median',np.median(A[:,1]),' fee max',A[:,2].max())
    def rep(mask,label):
        R_=A[mask,1].sum(); F=A[mask,2].sum(); L=A[mask,3].sum(); d=mask.sum()/24
        print(f' {label:14s} d={d:5.0f} rew/day(FR)={R_/d*1e4:6.3f}bp fee_unst/day={F/d*1e4:6.3f}bp loss/day={L/d*1e4:6.3f}bp | STAKED rew/loss raw {R_/L:.3f} corr {R_/(0.77*L):.3f} | UNSTAKED fee/loss raw {F/L:.3f} corr {F/(0.77*L):.3f} | ±1% rew %/day {R_/d*lev(1.01)*100:.3f}')
    rep(np.ones(len(A),bool),'ALL')
    mid=t[0]+(t[-1]-t[0])/2
    rep(t<mid,'1st half'); rep(t>=mid,'2nd half')
    for w in [30,90]:
        rep(t>=t[-1]-w*86400,f'last {w}d')
    regs=np.array([r[4] for r in rs])
    for g in ['CALM','WARM','HOT']: rep(regs==g,g)
